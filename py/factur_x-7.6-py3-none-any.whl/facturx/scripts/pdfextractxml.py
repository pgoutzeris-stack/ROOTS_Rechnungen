#! /usr/bin/env python
# Copyright 2017-2023 Alexis de Lattre <alexis.delattre@akretion.com>

import argparse
import logging
import sys
from os.path import isdir, isfile

from facturx import __version__ as fxversion
from facturx import configure_script_logging, get_xml_from_pdf

__author__ = "Alexis de Lattre <alexis.delattre@akretion.com>"
__date__ = "October 2026"
__version__ = "0.5"

logger = logging.getLogger("factur-x")


def pdfextractxml(args):
    logger.info(
        "pdfextractxml version %s using factur-x lib version %s", __version__, fxversion
    )

    pdf_filename = args.facturx_orderx_file
    out_xml_filename = args.xml_file_to_create
    if not isfile(pdf_filename):
        logger.error("Argument %s is not a filename", pdf_filename)
        sys.exit(1)
    if isdir(out_xml_filename):
        logger.error(
            "2nd argument %s is a directory name (should be a the "
            "output XML filename)",
            out_xml_filename,
        )
        sys.exit(1)
    check_xsd = not args.disable_xsd_check
    check_schematron = not args.disable_schematron_check
    xml_filename = xml_string = None
    with open(pdf_filename, "rb") as pdf_file:
        try:
            (xml_filename, xml_string) = get_xml_from_pdf(
                pdf_file, check_xsd=check_xsd, check_schematron=check_schematron
            )
        except Exception as e:
            logger.error(e)
            sys.exit(1)
    if xml_filename and xml_string:
        if isfile(out_xml_filename):
            logger.warning("File %s already exists. Overwriting it!", out_xml_filename)
        with open(out_xml_filename, "wb") as xml_file:
            xml_file.write(xml_string)
        logger.info("File %s generated", out_xml_filename)
    else:
        logger.warning("File %s has not been created", out_xml_filename)
        sys.exit(1)


def main(args=None):
    if args is None:
        args = sys.argv[1:]
    usage = "facturx-pdfextractxml <facturx_orderx_file> <xml_file_to_create>"
    epilog = f"Author: {__author__} - Version: {__version__}"
    description = "This extracts the XML file from a Factur-X or Order-X PDF file."
    parser = argparse.ArgumentParser(
        usage=usage, epilog=epilog, description=description
    )
    parser.add_argument(
        "-l",
        "--log-level",
        dest="log_level",
        choices=["debug", "info", "warn", "error"],
        default="info",
        help="Set log level. Default value: info.",
    )
    parser.add_argument(
        "-d",
        "--disable-xsd-check",
        dest="disable_xsd_check",
        action="store_true",
        help="De-activate XML Schema Definition check on Factur-X/Order-X XML file "
        "(the check is enabled by default)",
    )
    parser.add_argument(
        "-ds",
        "--disable-schematron-check",
        dest="disable_schematron_check",
        action="store_true",
        help="De-activate Schematron check on Factur-X/Order-X XML file "
        "(the check is enabled by default)",
    )
    parser.add_argument("facturx_orderx_file", help="PDF Factur-X or Order-X file")
    parser.add_argument(
        "xml_file_to_create",
        help="Filename of the XML file that will be extracted from the PDF",
    )
    args = parser.parse_args()
    log_map = {
        "debug": logging.DEBUG,
        "info": logging.INFO,
        "warn": logging.WARN,
        "error": logging.ERROR,
    }
    configure_script_logging(level=log_map[args.log_level])
    pdfextractxml(args)


def run():
    if __name__ == "__main__":
        main()


run()
